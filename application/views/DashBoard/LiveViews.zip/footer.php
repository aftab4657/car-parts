        <footer class="footer">
          <div class="w-100 clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2020 <a href="#" >eSync</a>. All rights reserved.</span>
          </div>
        </footer>